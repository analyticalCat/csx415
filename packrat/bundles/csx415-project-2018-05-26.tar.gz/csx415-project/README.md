#Overview 

The purpose of this project is to analyze the past campaign data, and to build a sustainable machine learning model to predict future campaign outcome.  

#Project Content
-This project contains scripts, data, a machine learning model and a scoring package to help users to predict future campaign outcome.
-The deployment instruction can be found in "bankingclientsprofile/deploy/readme.md."
-Asset.md contains a list of all useful resources in this project.