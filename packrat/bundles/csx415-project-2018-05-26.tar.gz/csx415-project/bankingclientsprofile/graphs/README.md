Here you can store any graphs that you produce.
