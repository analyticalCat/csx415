past_campaign_data.csv: contains data used for building the model.
next_campaign_data.csv: contains data used for scoring.