# CSX415 Project: Telephone Campaign Result Prediction

## Deployment

### RStudio

Copy the `xxx.gz` file from the `/deploy` directory to the location where you want to install and then open RStudio. Replace the following script with the project folder of your choice and run the script in the console:

``` r
setwd("<Your project folder>")
library('packrat')
packrat::unbundle("xx.gz", ".")
```

The package contains one method for scoring: xxxxx

You can pass the name and path of an input file as the parameter 

``` r

```
