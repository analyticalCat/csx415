## Test environments
* local Ubuntu install, R 3.3.1
* ubuntu 12.04 (on travis-ci), R 3.3.1
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 0 notes

## Reverse dependencies

* I have run R CMD check on the one downstream dependency, `reports`. The check
  found a NOTE that is most likely unrelated to the `ProjectTemplate` update.
